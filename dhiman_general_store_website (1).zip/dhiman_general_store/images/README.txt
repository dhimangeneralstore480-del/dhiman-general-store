Place your product photos in this folder and reference them from products.js.
