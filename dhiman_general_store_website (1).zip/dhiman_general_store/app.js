/* Dhiman General Store - front-end cart and WhatsApp checkout */
(() => {
  "use strict";
  // IMPORTANT: Replace this with the shop's WhatsApp number including country code, digits only.
  // India example: 91 + 10-digit mobile number. Do not include +, spaces or dashes.
  const WHATSAPP_NUMBER = "919805688591";
  const CATEGORIES = [
    {name:"All",emoji:"🛍️"},
    {name:"Grocery",emoji:"🌾"},
    {name:"Snacks",emoji:"🍪"},
    {name:"Beverages",emoji:"🧃"},
    {name:"Dairy",emoji:"🥛"},
    {name:"Personal Care",emoji:"🧴"},
    {name:"Home Care",emoji:"🧽"}
  ];
  const $ = (id) => document.getElementById(id);
  const money = (n) => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(n);
  let selectedCategory = "All";
  let cart = {};
  try { cart = JSON.parse(sessionStorage.getItem("dhiman-cart") || "{}") || {}; } catch (_) { cart = {}; }

  const products = (window.STORE_PRODUCTS || []).map(p => ({...p, price:Number(p.price)||0, mrp:Number(p.mrp)||0, stock:Number(p.stock)||0}));
  const categoriesEl = $("categories"), grid = $("product-grid"), search = $("search"), sort = $("sort");
  const overlay = $("overlay"), drawer = $("cart-drawer"), toastEl = $("toast");
  let toastTimer;
  const safe = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const discount = p => p.mrp > p.price ? Math.round((p.mrp-p.price)/p.mrp*100) : 0;
  const qty = id => Number(cart[id] || 0);
  const saveCart = () => { try { sessionStorage.setItem("dhiman-cart", JSON.stringify(cart)); } catch (_) {} };
  function showToast(msg) { toastEl.textContent = msg; toastEl.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>toastEl.classList.remove("show"),2200); }
  function imageMarkup(p, cls="") {
    if (p.image) return `<img class="${cls}" src="${safe(p.image)}" alt="${safe(p.name)}" loading="lazy" onerror="this.remove();this.parentElement.insertAdjacentHTML('beforeend','<span class=\\'photo-placeholder\\'>${safe(p.emoji||"🛍️")}</span>')">`;
    return `<span class="photo-placeholder" aria-hidden="true">${safe(p.emoji||"🛍️")}</span>`;
  }
  function renderCategories() {
    categoriesEl.innerHTML = CATEGORIES.map(c => `<button class="category-btn ${selectedCategory===c.name?"active":""}" data-category="${safe(c.name)}"><span class="category-emoji">${c.emoji}</span><span>${safe(c.name==="All"?"All products":c.name)}</span></button>`).join("");
    categoriesEl.querySelectorAll("button").forEach(b => b.addEventListener("click",()=>{selectedCategory=b.dataset.category;renderCategories();renderProducts();}));
  }
  function visibleProducts() {
    const term = search.value.trim().toLowerCase();
    let list = products.filter(p => (selectedCategory==="All" || p.category===selectedCategory) && (!term || [p.name,p.category,p.brand,p.size,p.description].join(" ").toLowerCase().includes(term)));
    switch(sort.value) {
      case "price-low": list.sort((a,b)=>a.price-b.price); break;
      case "price-high": list.sort((a,b)=>b.price-a.price); break;
      case "name": list.sort((a,b)=>a.name.localeCompare(b.name)); break;
      default: list.sort((a,b)=>Number(Boolean(b.featured))-Number(Boolean(a.featured)) || a.name.localeCompare(b.name));
    }
    return list;
  }
  function renderProducts() {
    const list=visibleProducts();
    $("results-label").textContent=`Showing ${list.length} product${list.length===1?"":"s"} · sample catalogue`;
    $("active-filter").textContent=selectedCategory==="All"?"":`Category: ${selectedCategory}  ·  ${list.length} item${list.length===1?"":"s"}`;
    $("empty-state").classList.toggle("hidden",list.length!==0);
    grid.innerHTML=list.map(p=>{
      const d=discount(p), q=qty(p.id);
      return `<article class="product-card">
        <div class="product-photo">${imageMarkup(p)}${d?`<span class="discount-badge">${d}% OFF</span>`:""}</div>
        <div class="product-info"><div class="product-category">${safe(p.category)}</div><h3>${safe(p.name)}</h3><div class="pack-size">${safe(p.size||"Pack size varies")}</div>
        <div class="price-row"><span class="selling-price">${money(p.price)}</span>${p.mrp>p.price?`<span class="mrp">${money(p.mrp)}</span>`:""}</div>
        ${p.stock<=0?`<button class="add-btn" disabled>Out of stock</button>`:q?`<div class="qty-control"><button data-action="minus" data-id="${safe(p.id)}" aria-label="Remove one ${safe(p.name)}">−</button><span>${q} in cart</span><button data-action="plus" data-id="${safe(p.id)}" aria-label="Add one ${safe(p.name)}">+</button></div>`:`<button class="add-btn" data-action="plus" data-id="${safe(p.id)}">＋ Add</button>`}
        </div></article>`;
    }).join("");
    grid.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>changeQty(b.dataset.id,b.dataset.action==="plus"?1:-1)));
  }
  function changeQty(id,delta) {
    const p=products.find(x=>x.id===id); if(!p)return;
    const next=qty(id)+delta;
    if(next<0)return;
    if(next>p.stock){showToast("Only "+p.stock+" available in sample stock.");return;}
    if(next===0)delete cart[id];else cart[id]=next;
    saveCart();renderProducts();renderCart();
    if(delta>0)showToast("Added to your cart");
  }
  function cartEntries(){return products.filter(p=>qty(p.id)>0).map(p=>({...p,quantity:qty(p.id)}));}
  function renderCart() {
    const entries=cartEntries(), count=entries.reduce((s,p)=>s+p.quantity,0), total=entries.reduce((s,p)=>s+p.price*p.quantity,0);
    $("cart-count").textContent=count; $("drawer-count").textContent=`(${count})`; $("subtotal").textContent=money(total);
    $("cart-empty").classList.toggle("hidden",entries.length>0); $("cart-summary").classList.toggle("hidden",entries.length===0);
    $("cart-items").innerHTML=entries.map(p=>`<div class="cart-row"><div class="cart-thumb">${p.image?`<img src="${safe(p.image)}" alt="">`:safe(p.emoji||"🛍️")}</div><div><h4>${safe(p.name)}</h4><small>${safe(p.size||"")} · ${money(p.price)} each</small><div class="mini-qty"><button data-cart-delta="-1" data-id="${safe(p.id)}">−</button><span>${p.quantity}</span><button data-cart-delta="1" data-id="${safe(p.id)}">+</button></div></div><div class="line-price">${money(p.price*p.quantity)}</div></div>`).join("");
    $("cart-items").querySelectorAll("[data-cart-delta]").forEach(b=>b.addEventListener("click",()=>changeQty(b.dataset.id,Number(b.dataset.cartDelta))));
  }
  function openCart(){overlay.classList.remove("hidden");drawer.classList.add("open");drawer.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";}
  function closeCart(){overlay.classList.add("hidden");drawer.classList.remove("open");drawer.setAttribute("aria-hidden","true");document.body.style.overflow="";}
  function whatsappLink(text){return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;}
  $("checkout-form").addEventListener("submit",e=>{
    e.preventDefault();
    const entries=cartEntries(); if(!entries.length){showToast("Your cart is empty");return;}
    if(!/^\d{10,15}$/.test(WHATSAPP_NUMBER)){showToast("Please set the shop WhatsApp number in app.js");return;}
    const fd=new FormData(e.currentTarget);
    const name=String(fd.get("customerName")||"").trim(), phone=String(fd.get("customerPhone")||"").trim(), address=String(fd.get("customerAddress")||"").trim(), note=String(fd.get("customerNote")||"").trim();
    const total=entries.reduce((s,p)=>s+p.price*p.quantity,0);
    const lines=["*NEW ORDER — DHIMAN GENERAL STORE*","",`Name: ${name}`,`Customer phone: ${phone}`,`Delivery address: ${address}`,"","*Items:*",...entries.map(p=>`• ${p.name} (${p.size||"pack"}) × ${p.quantity} = ${money(p.price*p.quantity)}`),"",`*Catalogue subtotal: ${money(total)}*`,"Delivery fee and final total: to be confirmed by shop",note?`Note: ${note}`:"","Please confirm stock and delivery availability."].filter(Boolean);
    window.open(whatsappLink(lines.join("\n")),"_blank","noopener");
  });
  $("open-cart").addEventListener("click",openCart); $("close-cart").addEventListener("click",closeCart); overlay.addEventListener("click",closeCart);
  $("continue-shopping").addEventListener("click",()=>{closeCart();$("products").scrollIntoView({behavior:"smooth"});});
  search.addEventListener("input",renderProducts); sort.addEventListener("change",renderProducts);
  $("ask-whatsapp").href=whatsappLink("Hello Dhiman General Store, I would like to ask about product availability and local delivery around Sunhi.");
  $("year").textContent=new Date().getFullYear();
  renderCategories();renderProducts();renderCart();
})();