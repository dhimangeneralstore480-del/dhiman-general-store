# DHIMAN GENERAL STORE — website starter

A responsive, static HTML/CSS/JavaScript catalogue for a local general store. Includes category filters, search, product cards, MRP/selling price, stock limits, a cart and WhatsApp order handoff.

## Important before publishing
- This is a front-end catalogue, not a full Blinkit clone. It has no online payment, customer accounts, delivery tracking, shared live inventory, or secure admin dashboard.
- `products.js` contains illustrative sample products and prices. Replace them with your actual catalogue, exact pack sizes, printed MRPs, and intended selling prices before taking orders.
- Product images are blank by default, so emoji placeholders display. Add real product photos to `images/` and set each product's `image` field, e.g. `image:"images/atta-5kg.jpg"`.
- In `app.js`, set `WHATSAPP_NUMBER` to the shop's WhatsApp number in international digits-only format. Example India format: `91` + 10-digit number. The current default points to the first contact number supplied for the shop; verify it can receive WhatsApp messages.
- The second contact number is shown in the footer, but checkout messages go only to the configured WhatsApp number.
- The site currently lists Sunhi as its local service area. Confirm delivery radius, fees, minimum order, and timings directly with customers.

## Test locally
1. Download and extract the ZIP.
2. Open `index.html` in Chrome or Edge.
3. Search, choose categories, add items to cart, enter sample checkout details, and test the WhatsApp button. A WhatsApp tab/message should open; the customer must press Send.
4. For best testing, use a local static server (VS Code Live Server extension) rather than opening the file directly.

## Edit products
Open `products.js` in Notepad or VS Code. Each product looks like:
```js
{id:"DGS021",name:"Product name",category:"Grocery",brand:"Brand",size:"1 kg",mrp:100,price:90,stock:10,image:"images/product.jpg",emoji:"🛍️",description:"Short description",featured:false}
```
- `id` must be unique.
- `category` should match one of: `Grocery`, `Snacks`, `Beverages`, `Dairy`, `Personal Care`, `Home Care`. Add more categories to `CATEGORIES` in `app.js` if needed.
- `mrp` and `price` are numbers in rupees. Don't set the selling price above the applicable MRP.
- `stock` is a sample quantity limit on this browser only. It is not synced between customers.
- `image` is a path relative to `index.html`. Keep filenames simple, e.g. `images/soap-100g.jpg`.

## Add product photos
1. Take clear photos of the exact product pack you sell, or use brand-authorized product images.
2. Crop with the product centred; use JPG or WebP for smaller file size.
3. Copy the image to the `images` folder.
4. Add its path to the matching product's `image` field in `products.js`.
5. Refresh the page and check the image on mobile and desktop.

## Publish free with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a public repository, e.g. `dhiman-general-store`.
3. Upload `index.html`, `styles.css`, `products.js`, `app.js`, `README.md`, and the `images` folder (keep the folder structure).
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
6. Wait for deployment; GitHub displays your site URL, usually `https://YOUR-USERNAME.github.io/dhiman-general-store/`.
7. Test the published site on a phone and send a test order to the shop number.
8. To update the catalogue later, edit and upload `products.js` or replace photos. Pages rebuilds automatically.

Free hosting and a GitHub Pages URL are enough for this static starter. A custom domain is optional and normally costs money.

## Local delivery operations checklist
- Decide which villages/areas you deliver to.
- Decide delivery timings, fee, minimum order and whether pickup is available.
- Confirm availability before promising a product.
- Check each WhatsApp order and call/message the customer if details are incomplete.
- Keep a manual stock/pricing sheet until you adopt a real backend.
- Don't collect card details or sensitive personal data on this static website.

## For a true live store later
Add a backend/database and admin login, shared stock updates, order management, payment gateway, delivery zones, privacy/terms pages, backups and appropriate security. A static GitHub Pages site cannot securely provide an admin panel or shared stock by itself.
