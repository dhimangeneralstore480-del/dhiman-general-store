/*
  PRODUCT CATALOGUE
  Edit products here. Duplicate an object to add more products.
  image: use a relative path such as "images/atta.jpg", or leave "" to show emoji.
  mrp and price are numbers in INR. Keep prices accurate to the actual pack.
*/
window.STORE_PRODUCTS = [
  {id:"DGS001",name:"Wheat Flour (Atta)",category:"Grocery",brand:"Sample",size:"5 kg",mrp:300,price:270,stock:25,image:"",emoji:"🌾",description:"Everyday wheat flour",featured:true},
  {id:"DGS002",name:"Basmati Rice",category:"Grocery",brand:"Sample",size:"1 kg",mrp:120,price:110,stock:20,image:"",emoji:"🍚",description:"Rice for everyday meals",featured:true},
  {id:"DGS003",name:"Toor Dal",category:"Grocery",brand:"Sample",size:"1 kg",mrp:160,price:145,stock:15,image:"",emoji:"🫘",description:"Pulses and lentils",featured:true},
  {id:"DGS004",name:"Cooking Oil",category:"Grocery",brand:"Sample",size:"1 litre",mrp:160,price:145,stock:18,image:"",emoji:"🫗",description:"Cooking oil",featured:true},
  {id:"DGS005",name:"Sugar",category:"Grocery",brand:"Sample",size:"1 kg",mrp:50,price:48,stock:30,image:"",emoji:"🧂",description:"Daily kitchen essential"},
  {id:"DGS006",name:"Salt",category:"Grocery",brand:"Sample",size:"1 kg",mrp:25,price:22,stock:40,image:"",emoji:"🧂",description:"Iodised salt"},
  {id:"DGS007",name:"Tea",category:"Beverages",brand:"Sample",size:"250 g",mrp:140,price:130,stock:12,image:"",emoji:"🍵",description:"Tea for your daily cup"},
  {id:"DGS008",name:"Glucose Biscuits",category:"Snacks",brand:"Sample",size:"Pack",mrp:10,price:10,stock:50,image:"",emoji:"🍪",description:"Tea-time biscuits"},
  {id:"DGS009",name:"Potato Chips",category:"Snacks",brand:"Sample",size:"Pack",mrp:20,price:20,stock:35,image:"",emoji:"🥔",description:"Crispy snack"},
  {id:"DGS010",name:"Chocolate",category:"Snacks",brand:"Sample",size:"Bar",mrp:40,price:35,stock:22,image:"",emoji:"🍫",description:"Chocolate treat"},
  {id:"DGS011",name:"Packaged Drinking Water",category:"Beverages",brand:"Sample",size:"1 litre",mrp:20,price:20,stock:60,image:"",emoji:"💧",description:"Packaged water"},
  {id:"DGS012",name:"Fruit Juice",category:"Beverages",brand:"Sample",size:"1 litre",mrp:120,price:110,stock:10,image:"",emoji:"🧃",description:"Fruit drink"},
  {id:"DGS013",name:"Bathing Soap",category:"Personal Care",brand:"Sample",size:"Pack",mrp:40,price:35,stock:24,image:"",emoji:"🧼",description:"Daily personal care"},
  {id:"DGS014",name:"Shampoo",category:"Personal Care",brand:"Sample",size:"Bottle",mrp:120,price:110,stock:12,image:"",emoji:"🧴",description:"Hair care"},
  {id:"DGS015",name:"Toothpaste",category:"Personal Care",brand:"Sample",size:"Pack",mrp:100,price:90,stock:16,image:"",emoji:"🪥",description:"Oral care"},
  {id:"DGS016",name:"Detergent Powder",category:"Home Care",brand:"Sample",size:"Pack",mrp:120,price:110,stock:20,image:"",emoji:"🫧",description:"Laundry care"},
  {id:"DGS017",name:"Dishwash Bar",category:"Home Care",brand:"Sample",size:"Bar",mrp:25,price:22,stock:28,image:"",emoji:"🧽",description:"Kitchen cleaning"},
  {id:"DGS018",name:"Floor Cleaner",category:"Home Care",brand:"Sample",size:"Bottle",mrp:110,price:99,stock:9,image:"",emoji:"🧹",description:"Home cleaning"},
  {id:"DGS019",name:"Milk",category:"Dairy",brand:"Sample",size:"500 ml",mrp:30,price:30,stock:20,image:"",emoji:"🥛",description:"Milk; confirm today's availability"},
  {id:"DGS020",name:"Instant Noodles",category:"Snacks",brand:"Sample",size:"Pack",mrp:15,price:14,stock:30,image:"",emoji:"🍜",description:"Quick snack"}
];